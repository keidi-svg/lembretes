let usuario=JSON.parse(localStorage.getItem("logado"));
document.getElementById("titulo").innerHTML="Bem vindo, "+usuario.login+" !";
 function deslogar(){
     window.location.href="../index.html"
 }


 let lembretes = [];

// Evento disparado quando o DOM é carregado
document.addEventListener("DOMContentLoaded", function () {
    // Função para carregar dados na tabela
    carrega();

    // Elementos do modal novo Lembrete
    let btnNovoLembrete = document.getElementById("btnNovoLembrete");
    let btnEditarLembrete = document.getElementById("btnEditarLembrete");
    let modalNovoLembrete = document.getElementById("modalNovoLembrete");
    let modalEditarLembrete = document.getElementById("modalEditarLembrete");
    let spanNovoLembrete = modalNovoLembrete.querySelector(".close");
    let spanEditarLembrete = modalEditarLembrete.querySelector(".close");


    // Configurando eventos do modal novo lembrete
    btnNovoLembrete.onclick = function () {
        modalNovoLembrete.style.display = "block";
    };

    spanNovoLembrete.onclick = function () {
        modalNovoLembrete.style.display = "none";
    };

    btnEditarLembrete.onclick = function () {
        modalEditarLembrete.style.display = "block";
    };

    spanEditarLembrete.onclick = function () {
        modalEditarLembrete.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target == modalNovoLembrete) {
            modalNovoLembrete.style.display = "none";
        }
    };

    window.onclick = function (event) {
        if (event.target == modalEditarLembrete) {
            modalEditarLembrete.style.display = "none";
        }
    };


    // Adicionando eventos aos botões da tabela
    let botoesInfo = document.querySelectorAll('.btn-info');
    //let botoesEditar = document.querySelectorAll('.btn-editar');

    for (let i = 0; i < botoesInfo.length; i++) {
        botoesInfo[i].onclick = function () {
        modal(this);
    };}
    //for (let i = 0; i < botoesEditar.length; i++) {
    //    botoesEditar[i].onclick = function () {
    //        modal(this);
    //    };
    //}
});

 //Função para identificar lembrete por id
function identifica(id) {
    for (let lembrete of lembretes) {
        if (lembrete.id === id.id) {
            return lembrete;
        }
    }
    return null;
}

// Função para exibir modal de informações do lembrete
function modal(button) {
    let lembrete = identifica(button);

    let modal = document.getElementById("myModal");

    if (!modal) {
        console.error("Elemento 'myModal' não encontrado no DOM");
        return;
    }

    let span = modal.querySelector(".close");
    if (!span) {
        console.error("Elemento 'close' não encontrado no DOM");
        return;
    }

    // Elementos do modal de informações do lembrete
    let idModal = modal.querySelector("#idModal");
    let nomeModal = modal.querySelector("#nomeModal");
    let dataModal = modal.querySelector("#dataModal");
    let categoriaModal = modal.querySelector("#categoriaModal");
    let lembreteModal = modal.querySelector("#lembreteModal");
    let btnExcluirLembrete = modal.querySelector("#btnExcluirLembrete");

    if (!idModal || !nomeModal || !dataModal || !categoriaModal || !lembreteModal || !btnExcluirLembrete) {
        console.error("Elementos não encontrados no DOM");
        return;
    }

    // Preenchendo informações no modal
    idModal.innerHTML = lembrete.id;
    nomeModal.innerHTML = lembrete.nome;
    dataModal.innerHTML = lembrete.data;
    categoriaModal.innerHTML = lembrete.categoria;
    lembreteModal.innerHTML = lembrete.lembrete;

    // Configurando o botão de excluir
    btnExcluirLembrete.onclick = function () {
        excluirLembrete(lembrete.id);
        modal.style.display = "none";
    };

    span.onclick = function () {
        modal.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };

    modal.style.display = "block";
}

// Função para excluir lembrete
function excluirLembrete(id) {
    lembretes = lembretes.filter(lembrete => lembrete.id !== id);
    localStorage.setItem("lembretes", JSON.stringify(lembretes));
    carrega();
}

// Função para carregar dados na tabela
// Adicione esta função para criar o botão de editar na tabela
function criarBotaoEditar(id) {
    return `<td><button id='btnEditar-${id}' class='btn-editar' onclick='preencherFormularioEdicao("${id}")'>Editar</button></td>`;
}

// Atualize a função carrega para incluir o botão de editar
// ...

// Atualize a função carrega para incluir o botão de editar
function carrega() {
    let tabela = document.getElementById("lembretes");
    lembretes = JSON.parse(localStorage.getItem("lembretes")) || [];

    tabela.innerHTML = "";

    for (let lembrete of lembretes) {
        let botaoid = `<td><button id='${lembrete.id}' class='btn-info'>Mais info</button></td>`;
        let botaoEditar = criarBotaoEditar(lembrete.id);
        let linha = `<tr>
            <td>${lembrete.id}</td>
            <td>${lembrete.nome}</td>
            <td>${lembrete.data}</td>
            <td>${lembrete.categoria}</td>
            <td>${lembrete.lembrete}</td>
            ${botaoid}
            ${botaoEditar}
            </tr>`;
        tabela.innerHTML += linha;
    }

    // Adicionando eventos aos botões da tabela
    let botoesInfo = document.querySelectorAll('.btn-info');
    let botoesEditar = document.querySelectorAll('.btn-editar');

    for (let i = 0; i < botoesInfo.length; i++) {
        botoesInfo[i].onclick = function () {
            modal(this);
        };
    }

    // O evento de clique para os botões de editar deve ser configurado aqui
    for (let i = 0; i < botoesEditar.length; i++) {
        botoesEditar[i].onclick = function () {
            let id = this.id.split('-')[1]; // Obtém o ID do botão de editar
            preencherFormularioEdicao(id);
        };
    }
}

// ...

// Remova a função modal do evento de clique nos botões de editar na função carrega

// ...

// Ajuste a função para abrir corretamente o modal de edição
function preencherFormularioEdicao(id) {
    let lembrete = lembretes.find(item => item.id === id);

    document.getElementById("editNome").value = lembrete.nome;
    document.getElementById("editData").value = lembrete.data;
    document.getElementById("editCategoria").value = lembrete.categoria;
    document.getElementById("editLembrete").value = lembrete.lembrete;

    // Exibe o modal de editar lembrete
    document.getElementById("modalEditarLembrete").style.display = "block";
}

// ...

// O resto do seu código permanece inalterado...


// Função para cadastrar novo lembete
function cadastrarLembrete() {

    let nome = document.getElementById("nome").value;
    let data = document.getElementById("data").value;
    let categoria = document.getElementById("categoria").value;
    let lembrete = document.getElementById("lembrete").value;

    let id = lembretes.length + 1;

    // Verifica se a placa já está cadastrada
    if (lembreteExistente(id.toString())) {
        alert("ID já cadastrado. Tente novamente.");
        return;
    }

    let novoLembrete = {
        id: id.toString(),
        nome: nome,
        data: data,
        categoria: categoria,
        lembrete: lembrete
    };

    lembretes = JSON.parse(localStorage.getItem("lembretes")) || [];
    lembretes.push(novoLembrete);

    // Salva no localStorage
    localStorage.setItem("lembretes", JSON.stringify(lembretes));

    // Recarrega a tabela após cadastrar um novo lembrete
    carrega();

    // Esconde o modal de novo lembrete
    modalNovoLembrete.style.display = "none";
}


// Função para verificar se o lembrete já existe
function lembreteExistente(id) {
    return lembretes.some(lembrete => lembrete.id === id);
}

// Função para editar um lembrete
// Assume editId is defined somewhere in your code or passed as a parameter

// Função para editar um lembrete
// Função para editar um lembrete
function editarLembrete(editId) {
    let editNome = document.getElementById("editNome").value;
    let editData = document.getElementById("editData").value;
    let editCategoria = document.getElementById("editCategoria").value;
    let editLembrete = document.getElementById("editLembrete").value;

    // Verifica se o lembrete a ser editado existe
    if (!lembreteExistente(editId)) {
        alert("Lembrete não encontrado para edição.");
        return;
    }

    // Encontra o índice do lembrete a ser editado
    let index = lembretes.findIndex(lembrete => lembrete.id === editId);

    // Atualiza os dados do lembrete
    lembretes[index] = {
        nome: editNome,
        data: editData,
        categoria: editCategoria,
        lembrete: editLembrete
    };

    // Atualiza no localStorage
    localStorage.setItem("lembretes", JSON.stringify(lembretes));

    // Recarrega a tabela após editar um lembrete
    carrega();

    // Esconde o modal de editar lembrete
    document.getElementById("modalEditarLembrete").style.display = "none";
}


// Função para preencher o formulário de edição com os dados do lembrete
function preencherFormularioEdicao(id) {
    let lembrete = lembretes.find(item => item.id === id);

    document.getElementById("editNome").value = lembrete.nome;
    document.getElementById("editData").value = lembrete.data;
    document.getElementById("editCategoria").value = lembrete.categoria;
    document.getElementById("editLembrete").value = lembrete.lembrete;

    // Exibe o modal de editar lembrete
    document.getElementById("modalEditarLembrete").style.display = "block";
}

